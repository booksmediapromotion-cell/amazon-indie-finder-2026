"""Database models"""
from sqlalchemy import create_engine, Column, Integer, String, Text, Date, DateTime, Float, Boolean, ForeignKey, Index
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime, date

Base = declarative_base()

class Author(Base):
    __tablename__ = 'authors'
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False, index=True)
    website = Column(String(500))
    email = Column(String(255))
    state = Column(String(100), index=True)
    country = Column(String(100), default='USA')
    instagram = Column(String(255))
    facebook = Column(String(255))
    linkedin = Column(String(255))
    author_source_url = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)
    books = relationship("Book", back_populates="author", cascade="all, delete-orphan")

class Book(Base):
    __tablename__ = 'books'
    id = Column(Integer, primary_key=True)
    title = Column(String(500), nullable=False, index=True)
    author_id = Column(Integer, ForeignKey('authors.id'), nullable=False, index=True)
    genre = Column(String(100), index=True)
    subgenre = Column(String(100))
    publication_date = Column(Date, nullable=False, index=True)
    publication_month = Column(String(20))
    publication_year = Column(Integer, nullable=False, index=True)
    amazon_url = Column(String(500))
    cover_image = Column(String(500))
    publisher = Column(String(255))
    publishing_type = Column(String(50), default='Unknown / Needs Verification')
    source_url = Column(String(500))
    date_found = Column(Date, nullable=False, index=True)
    first_seen = Column(Date, nullable=False)
    last_checked = Column(Date, nullable=False)
    verification_status = Column(String(50), default='Needs Review')
    indie_score = Column(Integer, default=0)
    author = relationship("Author", back_populates="books")

class DailyDiscoveryLog(Base):
    __tablename__ = 'daily_discovery_log'
    id = Column(Integer, primary_key=True)
    discovery_date = Column(Date, nullable=False, unique=True, index=True)
    books_found = Column(Integer, default=0)
    new_authors_found = Column(Integer, default=0)
    duplicates_removed = Column(Integer, default=0)
    failed_sources = Column(Integer, default=0)
    last_run_time = Column(DateTime)
    status = Column(String(50), default='pending')
